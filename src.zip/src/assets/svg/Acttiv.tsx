import * as React from "react"
import Svg, { Path } from "react-native-svg"
const Acttiv = (props) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    width={32}
    height={32}
    fill="none"
    {...props}
  >
    <Path
      fill="#FFA726"
      d="M29 22a4 4 0 1 1-8 0 4 4 0 0 1 8 0ZM7 18a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z"
      opacity={0.2}
    />
    <Path
      fill="#FFA726"
      d="M20.5 10a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm0-5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM25 17a4.999 4.999 0 1 0 0 9.998A4.999 4.999 0 0 0 25 17Zm0 8a3 3 0 1 1 0-5.999A3 3 0 0 1 25 25ZM7 17a5 5 0 1 0 0 9.999A5 5 0 0 0 7 17Zm0 8a3 3 0 1 1 0-6 3 3 0 0 1 0 6Zm17-10h-5a1 1 0 0 1-.707-.293L15 11.415 12.414 14l4.293 4.293A.999.999 0 0 1 17 19v6a1 1 0 0 1-2 0v-5.586l-4.707-4.707a1.001 1.001 0 0 1 0-1.415l4-4a1 1 0 0 1 1.415 0L19.413 13H24a1 1 0 0 1 0 2Z"
    />
  </Svg>
)
export default Acttiv
